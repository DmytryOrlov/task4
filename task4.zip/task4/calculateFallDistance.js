export function calculateFallDistance(time) {
    const g = 9.8; // Ускорение свободного падения
    return 0.5 * g * time * time;
  }
  