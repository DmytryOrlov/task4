export function greet(name) {
    console.log('Привет, ${name}!') ;
  }
  